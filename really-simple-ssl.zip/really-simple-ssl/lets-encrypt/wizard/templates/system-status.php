<?php defined( 'ABSPATH' ) or die();
?>
<div class="rsssl-section">
    <?php rsssl_progress_add('system-status');?>

    <?php /*
    <div class="rsssl-hidden rsssl-server_software rsssl-show-on-warning">
        <p>
            <?php _e("If you're absolutely sure you're running either Plesk or cPanel, you can force detection.","really-simple-ssl")?>&nbsp;
        </p>
        <br>
        <input class="button button-default" type="submit" value="<?php _e("Force Plesk",'really-simple-ssl')?>" name="rsssl-force-plesk">
        <input class="button button-default" type="submit" value="<?php _e("Force cPanel",'really-simple-ssl')?>" name="rsssl-force-cpanel">
    </div>
 */?>
</div>