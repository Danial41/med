<?php

	/* Silence is golden */