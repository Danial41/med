<?php
/**
 * Additional integration with third-party plugins.
 *
 * @author Webcraftic <wordpress.webraftic@gmail.com>
 * @copyright (c) 11.12.2018, Webcraftic
 * @version 1.0
 */

defined( 'ABSPATH' ) || die( 'Cheatin&#8217; uh?' );

require_once WCTLR_PLUGIN_DIR . '/includes/plugins/acf.php';
require_once WCTLR_PLUGIN_DIR . '/includes/plugins/asgaros.php';
require_once WCTLR_PLUGIN_DIR . '/includes/plugins/buddypress.php';